Enchanted Eyes / حال مې بل دی — Remotion Visual Asset Pack

01–04 are full background images.
05–08 are PNG overlays with alpha transparency.

01 BG_01_ENCHANTED_TWILIGHT
02 BG_02_VAST_MOUNTAINS
03 BG_03_MIDNIGHT_STARS
04 BG_04_INTIMATE_DARK
05 FG_01_DEPTH_LAYER (transparent)
06 EYE_MOTIF (transparent)
07 AFGHAN_MOTIF (transparent)
08 LIGHT_TEXTURE (transparent)
